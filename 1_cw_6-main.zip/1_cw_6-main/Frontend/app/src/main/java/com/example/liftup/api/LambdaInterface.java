package com.example.liftup.api;

public interface LambdaInterface<T> {

    public void doSomething(T result);
}
