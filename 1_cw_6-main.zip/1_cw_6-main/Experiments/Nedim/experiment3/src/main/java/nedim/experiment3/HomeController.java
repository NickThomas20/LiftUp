package nedim.experiment3;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class HomeController {
    @GetMapping("/")
    public String lineOne() {
        return "This is a Soccer Team table similar to those you can find on Google<br>"
        + "You can view, insert, edit, and delete teams using Postman.<br>"
        + "You can also view the league table that is displayed in order by points.";
    }
}
