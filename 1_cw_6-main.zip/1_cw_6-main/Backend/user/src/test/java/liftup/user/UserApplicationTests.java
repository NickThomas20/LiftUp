package liftup.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = UserApplicationTests.class)
class UserApplicationTests {

	@Test
	void contextLoads() {
	}

}
