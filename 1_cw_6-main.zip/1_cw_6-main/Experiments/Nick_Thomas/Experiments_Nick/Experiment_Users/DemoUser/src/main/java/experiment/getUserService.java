package experiment;

import experiment.user.User;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


@Service
public class getUserService {
    private static List<User> LoadAllUsers(){
        List<User> userObj = new ArrayList<User>();
        userObj.add(new User(20, "Nick", "Thomas", "nick02@iastate.edu"));
        userObj.add(new User(20, "Nedim", "Hodzic", "nedboi2@iastate.edu"));
        userObj.add(new User(20, "Elmin", "Didic", "Sk1mmy@iastate.edu"));
        userObj.add(new User(20, "Mitchell", "Talyat", "BigMintyMitch@iastate.edu"));
        return userObj;
    }

    //Needed to create this to be able to add to the userList
    private List<User> userAccount = LoadAllUsers();

    List<User> getUsers(){
        return userAccount;
    }
    //simple addUser method
    public String addUser(User user) {
        userAccount.add(user);
        return "This User was added";
    }

    //used email as unique identifer so you can't change that for this demo
    public String updateUser(User user) {
        //check if user obj exists if yes - update
        for(User currentUser: userAccount){
            if(Objects.equals(currentUser.getEmail(), user.getEmail())){
                currentUser.setEmail(user.getEmail());
                currentUser.setAge(user.getAge());
                currentUser.setFirst_name(user.getFirst_name());
                currentUser.setLast_name(user.getLast_name());
                return "User Profile Updated";
            }
        }
        return "Errored out";
    }

    //Method to delete the user with the remove if condition which checks to see if names are equal
    public void deleteUser(String name){
        userAccount.removeIf(c -> c.getFirst_name().equals(name));
    }

}
