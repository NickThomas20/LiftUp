package com.example.liftup.api;

/**
 * The base generic API interface for all APIs.
 */
public interface BaseApi {

}
