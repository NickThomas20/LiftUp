package com.example.experiment2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button _submitButton;

    private EditText[] _editTextFields;

    private CheckBox _robotCheckBox;

    private TextView _errorText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        _errorText = (TextView) findViewById(R.id.textView_error);

        _robotCheckBox = (CheckBox) findViewById(R.id.checkBox_robot);

        _editTextFields = new EditText[]
                {
                        (EditText) findViewById(R.id.editTextTextPersonName_name),
                        (EditText) findViewById(R.id.editTextTextEmailAddress_email),
                        (EditText) findViewById(R.id.editTextPhone_phone),
                        (EditText) findViewById(R.id.editTextDate_birthday),
                };

        _submitButton = (Button) findViewById(R.id.button_submit);
        _submitButton.setOnClickListener(v -> onSubmit());
    }

    public void onSubmit(){
        //check for some text in each thing
        //normally, it would be way more in depth than this
        for(int i = 0; i < _editTextFields.length; i++) {
            if (_editTextFields[i].getText().length() == 0) {
                onSubmitFail();
                return;
            }
        }

        //all had some text in them, so that is good enough for this experiment
        onSubmitSuccess();
    }

    private void onSubmitFail(){
        //let the user know what they did wrong
        _errorText.setText("ERROR: You did not enter text for 1 or more text fields above.");
    }

    private  void onSubmitSuccess(){
        //go to the next page or whatever
        if(_robotCheckBox.isChecked())
        {
            startActivity(new Intent(this, SuccessActivity.class));
        } else {
            startActivity(new Intent(this, RobotActivity.class));
        }
    }
}