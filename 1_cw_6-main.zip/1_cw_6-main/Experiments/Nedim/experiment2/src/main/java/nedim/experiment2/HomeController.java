package nedim.experiment2;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class HomeController {
    @GetMapping("/")
    public String lineOne() {
        return "This is a basic calculator using springboot.<br>This uses postman for the calculations.<br><br>" + 
        "To do a calculation POST to /calc on Postman and include the calculation as text in the body," + 
        "to view all calculations go to /Calculations or do GET /Calculations on Postman.<br>" +
        "To view a specific calculation go to /Calculations/# or do GET /Calculations/# on Postman.<br>" + 
        "To delete a calculation use DELETE /delete and in the body include text of what index to delete.<br>" + 
        "To clear use DELETE /clear.<br>" + 
        "To replace a specific calculation go use PUT /replace# and include the new equation in the body.<br>";
    }
}
