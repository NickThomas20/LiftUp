package nedim.experiment3;

public class Team {
    private String teamName;
    private int points;
    private int goalsScored;
    private int goalsConceded;
    private int goalDifference;

    //Constructor
    public Team(String teamName, int points, int goalsScored, int goalsConceded, int goalDifference) {
        this.teamName = teamName;
        this.points = points;
        this.goalsScored = goalsScored;
        this.goalsConceded = goalsConceded;
        this.goalDifference = goalDifference;
    }

    //Get Methods
    public String getName() {
        return teamName;
    }
    public int getPoints() {
        return points;
    }
    public int getGS() {
        return goalsScored;
    }
    public int getGC() {
        return goalsConceded;
    }
    public int getGD() {
        return goalDifference;
    }
}