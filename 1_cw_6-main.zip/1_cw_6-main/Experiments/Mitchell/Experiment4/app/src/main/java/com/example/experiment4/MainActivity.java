package com.example.experiment4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView _textView;

    private Switch[] _switches;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        _textView = findViewById(R.id.textView_number);

        _switches = new Switch[]
                {
                        findViewById(R.id.switch1),
                        findViewById(R.id.switch2),
                        findViewById(R.id.switch3),
                        findViewById(R.id.switch4),
                        findViewById(R.id.switch5),
                        findViewById(R.id.switch6),
                        findViewById(R.id.switch7),
                        findViewById(R.id.switch8),
                };

        //all switches call the same event
        for(Switch s : _switches)
        {
            //CompoundButton buttonView, boolean checked
            s.setOnCheckedChangeListener((bv, c) -> {
                evaluateSwitches();
            });
        }
    }

    private void evaluateSwitches()
    {
        //get a binary value from the switches
        StringBuilder sb = new StringBuilder();

        for(Switch s : _switches)
        {
            sb.append(s.isChecked() ? '1' : '0');
        }

        //convert to number
        int number = Integer.parseInt(sb.toString(), 2);

        //print that
        _textView.setText(Integer.toString(number));
    }
}