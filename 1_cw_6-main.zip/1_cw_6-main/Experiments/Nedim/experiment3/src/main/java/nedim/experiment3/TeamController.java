package nedim.experiment3;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;

@RestController
public class TeamController {
    HashMap<String, Team> premTeams = new HashMap<>();
    ArrayList<Team> premTeamsArray = new ArrayList<>();

    @GetMapping("/teams")
    public @ResponseBody HashMap<String, Team> showTeams() {
        return premTeams;
    }
    @GetMapping("/teams/{teamName}")
    public @ResponseBody Team showATeam(@PathVariable String teamName) {
        return premTeams.get(teamName);
    }
    @GetMapping("/table")
    public @ResponseBody ArrayList<Team> showTable() {
        for(int i = 0; i < premTeamsArray.size() - 1; i++) {
            int mostPoints = i;
            for(int j = i + 1; j < premTeamsArray.size(); j++) {
                if(premTeamsArray.get(j).getPoints() > premTeamsArray.get(mostPoints).getPoints()) {
                    mostPoints = j;
                }
                else if(premTeamsArray.get(j).getPoints() == premTeamsArray.get(mostPoints).getPoints()) {
                    if(premTeamsArray.get(j).getGD() > premTeamsArray.get(mostPoints).getGD()) {
                        mostPoints = j;
                    }
                }
            }

            Team temp = premTeamsArray.get(mostPoints);
            premTeamsArray.set(mostPoints, premTeamsArray.get(i));
            premTeamsArray.set(i, temp);
        }

        return premTeamsArray;
    }
    @PostMapping("/teams/add")
    public @ResponseBody String addTeam(@RequestBody Team team) {
        premTeams.put(team.getName(), team);
        premTeamsArray.add(team);
        return "Added " + team.getName() + " to the league table.";
    }
    @PutMapping("/teams/edit/{teamName}")
    public @ResponseBody String editTeam(@PathVariable String teamName, @RequestBody Team premTeam) {
        premTeams.replace(teamName, premTeam);
        for(int i = 0; i < premTeamsArray.size(); i++) {
            if(premTeamsArray.get(i).getName().equals(teamName)) {
                premTeamsArray.set(i, premTeam);
                break;
            }
        }
        return "Edited " + teamName + "'s stats.";
    }
    @DeleteMapping("/teams/delete/{teamName}")
    public @ResponseBody String deleteTeam(@PathVariable String teamName) {
        premTeams.remove(teamName);
        return "Removed " + teamName + " from the league table.";
    }
    @DeleteMapping("/teams/clear")
    public @ResponseBody String clearTeams() {
        premTeams.clear();
        return "Removed all teams.";
    }
}