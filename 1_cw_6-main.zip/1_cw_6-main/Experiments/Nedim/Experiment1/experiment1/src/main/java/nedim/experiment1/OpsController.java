package nedim.experiment1;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class OpsController {
    @GetMapping("/ops")
    public String opsPage() {
        return "Operations are addition (Add), subtraction (Minus), multiplication (Multi), and division (Divide).";
    }
}
