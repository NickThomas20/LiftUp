package nedim.experiment1;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class CalcController {
    @GetMapping("/calc")
    public float opsPage(@RequestParam(value = "num1", defaultValue = "0") float num1,
                         @RequestParam(value = "num2", defaultValue = "0") float num2,
                         @RequestParam(value = "op", defaultValue = "Add") String op) {
        float answer = 0;
        if(op.equals("Add")) {
            answer = num1 + num2;
        }
        else if(op.equals("Minus")) {
            answer = num1 - num2;
        }
        else if(op.equals("Multi")) {
            answer = num1 * num2;
        }
        else if(op.equals("Divide")) {
            answer = num1 / num2;
        }
        else {
            answer = -1;
        }
        return answer;
    }
}
