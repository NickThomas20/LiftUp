package com.example.experiment3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_SELECT_IMAGE = 123;

    private Button _selectButton;

    private ImageView _image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        _selectButton = findViewById(R.id.button_selectImage);
        _image = findViewById(R.id.imageView_image);

        _selectButton.setOnClickListener((v) -> {
            openImageChooserDialogue();
        });
    }

    private void openImageChooserDialogue(){
        //create an intent
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);

        //use it to open a file dialog for pictures
        startActivityForResult(Intent.createChooser(intent, "Select Photo"), REQUEST_CODE_SELECT_IMAGE);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        //did the dialog return something
        if(resultCode == RESULT_OK)
        {
            //make sure this dialog is a select image dialog
            if(requestCode == REQUEST_CODE_SELECT_IMAGE)
            {
                //get the "url" to the image
                Uri imageUri = data.getData();

                //make sure it exists
                if(imageUri != null)
                {
                    //update the image view
                    _image.setImageURI(imageUri);
                }
            }
        }
    }
}