package nedim.experiment1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Experiment1Application {

	public static void main(String[] args) {
		SpringApplication.run(Experiment1Application.class, args);
	}
}
