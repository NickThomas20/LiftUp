package nedim.experiment2;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;

@RestController
public class CalcController {
    ArrayList<String> calculations = new ArrayList<>();

    @GetMapping("/calculations")
    public @ResponseBody ArrayList<String> showCalculations() {
        return calculations;
    }
    @GetMapping("/calculations/{index}")
    public @ResponseBody String showCalculation(@PathVariable int index) {
        return calculations.get(index - 1);
    }
    @PostMapping("/calc")
    public @ResponseBody String createPerson(@RequestBody String calculation) {
        String[] split = calculation.split(" ");
        double one = Float.parseFloat(split[0]);  
        double two = Float.parseFloat(split[2]);
        double answer = 0;
        if(split[1].equals("+")) {
            answer = one + two;
        }
        else if(split[1].equals("-")) {
            answer = one - two;
        }
        else if(split[1].equals("*")) {
            answer = one * two;
        }
        else {
            answer = one / two;
        }

        String finalAnswer = calculation + " = " + String.valueOf(answer);
        calculations.add(finalAnswer);

        return finalAnswer;
    }
    @DeleteMapping("/delete")
    public @ResponseBody String deleteCalc(@RequestBody String index) {
        int intIndex = Integer.parseInt(index);
        intIndex--;
        String answer = calculations.get(intIndex);
        calculations.remove(intIndex);
        return answer + " has been deleted.";
    }
    @DeleteMapping("/clear")
    public @ResponseBody String clear() {
        calculations.clear();
        return "Calculator has been cleared.";
    }
    @PutMapping("/replace{index}")
    public @ResponseBody String updateCalc(@PathVariable String index, @RequestBody String calculation) {
        int intIndex = Integer.parseInt(index);
        intIndex--;

        String answerOld = calculations.get(intIndex);

        String[] split = calculation.split(" ");
        double one = Float.parseFloat(split[0]);  
        double two = Float.parseFloat(split[2]);
        double answer = 0;
        if(split[1].equals("+")) {
            answer = one + two;
        }
        else if(split[1].equals("-")) {
            answer = one - two;
        }
        else if(split[1].equals("*")) {
            answer = one * two;
        }
        else {
            answer = one / two;
        }

        String finalAnswer = calculation + " = " + String.valueOf(answer);
        calculations.set(intIndex, finalAnswer);
        return answerOld + " has been replaced with " + finalAnswer;
    }
}
