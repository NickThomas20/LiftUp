package com.example.experiment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class Activity2 extends AppCompatActivity {

    private Button _button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);


        _button2 = (Button)findViewById(R.id.button2);
        _button2.setOnClickListener(v -> openActivity1());
    }

    public  void openActivity1()
    {
        //open the activity
        startActivity(new Intent(this, MainActivity.class));
    }
}