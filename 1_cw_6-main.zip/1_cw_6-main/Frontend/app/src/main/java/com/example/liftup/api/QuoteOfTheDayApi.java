package com.example.liftup.api;
import com.example.liftup.*;

import retrofit2.http.GET;

public interface QuoteOfTheDayApi extends BaseApi{
//    @GET("/all-quotes")
//    Call<List<QuoteOfTheDay>> getQuotes();
//
//    @GET("/add-quote")
//    Call<QuoteOfTheDay> addQuote(@RequestBody QuoteOfTheDay quote);
//
//    //Randomize quotes
//    @GET("/all-quotes/random")
//    Call<QuoteOfTheDay> getRandomQuote();
}
