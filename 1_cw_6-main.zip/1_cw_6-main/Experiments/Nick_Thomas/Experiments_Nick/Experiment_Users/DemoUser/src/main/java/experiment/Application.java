package experiment;

import experiment.user.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

/**
 * PetClinic Spring Boot Application.
 * 
 * @author Vivek Bengre
 */

@SpringBootApplication
@RestController
public class Application {
	
    public static void main(String[] args) throws Exception {
        SpringApplication.run(Application.class, args);
    }


    //Created object from getUserService class
    @Autowired
   getUserService service;

    //Home Page
    @RequestMapping("/")
    public String welcome(){
        return "Hi User and welcome to my springboot application<br>"+ "This experiment was made to show how storing users might actually act in an environment <br>" + "To see users go to localhost:8080/UsersTest<br>"+ "To add a user through postman go to localhost:8080/addUser";
    }
    //All this method does is grab the users from getUserService and displays it to /UserTest
    @GetMapping("/UsersTest")
    public List<User> getUser(){
        return service.getUsers();
    }

    //Method to add a user to the database
    @PostMapping("/addUser")
    public String addUser(@RequestBody User user){
    return service.addUser(user);
    }

    //Method to update a users profile
    @PutMapping("/updateUser")
    public String updateUser(@RequestBody User user){
        return service.updateUser(user);
    }

    //method to delete a users profile, based off name
    @DeleteMapping("/deleteUser/{name}")
    public String delete(@PathVariable String name){
        service.deleteUser(name);
        return "user got deleted: " + name;
    }

}

