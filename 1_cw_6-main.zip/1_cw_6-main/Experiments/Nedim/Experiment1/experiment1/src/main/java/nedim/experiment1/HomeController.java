package nedim.experiment1;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class HomeController {
    @GetMapping("/")
    public String homePage() {
        return "Welcome to a basic calculator using spring boot. To view calculator operations and what commands to use " +
                "add /ops to the url. How to perform an operation: add /calc?num1=num1&num2=num2&op=op for example: " +
                "/calc?num1=3&num2=4&op=Add ";
    }
}
